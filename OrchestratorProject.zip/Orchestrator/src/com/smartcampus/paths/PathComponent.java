package com.smartcampus.paths;

public class PathComponent {
	private String _id;

	public String getId() {
		return this._id;
	}

	public void setId(String aId) {
		this._id = aId;
	}
}