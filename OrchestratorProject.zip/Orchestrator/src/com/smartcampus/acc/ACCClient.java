package com.smartcampus.acc;

public interface ACCClient {

	public void indoorParametersSetted();

	public void currentIndoorStatus(indoorStatus aIndoorStatus);
}