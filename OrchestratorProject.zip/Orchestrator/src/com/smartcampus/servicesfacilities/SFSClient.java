package com.smartcampus.servicesfacilities;

public interface SFSClient {

	public boolean foodOrderPlaced();

	public boolean cleaningFrequencySetted();
}