package com.smartcampus.servicesfacilities;

public class FoodList {
	private Food[] foods;

	public Food[] getFoods() {
		return this.foods;
	}

	public void setFoods(Food[] aFoods) {
		this.foods = aFoods;
	}
}