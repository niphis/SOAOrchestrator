package com.smartcampus.servicesfacilities;

public class Food {
	private String label;
	private int quantity;
	private String unit;

	public String getLabel() {
		return this.label;
	}

	public void setLabel(String aLabel) {
		this.label = aLabel;
	}

	public int getQuantity() {
		return this.quantity;
	}

	public void setQuantity(int aQuantity) {
		this.quantity = aQuantity;
	}

	public String getUnit() {
		return this.unit;
	}

	public void setUnit(String aUnit) {
		this.unit = aUnit;
	}
}