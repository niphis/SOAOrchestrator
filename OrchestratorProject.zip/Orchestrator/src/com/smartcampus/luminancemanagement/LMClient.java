package com.smartcampus.luminancemanagement;

public interface LMClient {

	public void roomLuminance();

	public void parameterSet();
}